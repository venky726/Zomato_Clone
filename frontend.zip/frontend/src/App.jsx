import React from 'react'
import Login from './pages/Login'
import Home from './pages/Home'
import Register from './pages/Register'
import Navbar from './components/Navbar'
import  './App.css'

const App = () => {
  return (
    <div>
      <Navbar />
    </div>
  )
}

export default App