import React from 'react'

const Navbar = () => {
  return (
    <div>
        <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="vite.svg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top"/>
      Bootstrap
    </a>
  </div>
</nav>
    </div>
  )
}

export default Navbar